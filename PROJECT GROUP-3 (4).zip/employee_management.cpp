/*
 ============================================================
  EMPLOYEE MANAGEMENT SYSTEM
  Features:
    1. Recruit  an Employee
    2. Retire   an Employee (auto-check on startup)
    3. Fire     an Employee
    4. Calculate Net Salary (all / single)
    5. Display  (all / single)
    6. Update   an Employee  (edit any field)
    7. Search   an Employee  (by ID or Name)
 ============================================================
  File storage : employee.txt  (pipe-delimited)
  Net Salary   : Basic - Tax(10%) - Pension(7%) + Transport(500)
  Retirement   : Age >= 60
 ============================================================
*/

#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <string>
#include <iomanip>
#include <algorithm>
#include <ctime>
#include <limits>
#include <cctype>
#include <cstdlib>

using namespace std;

// ============================================================
//  DATA STRUCTURES
// ============================================================

struct Date {
    int day;
    int month;
    int year;
};

struct Employee {
    int    id;
    string fname;
    string lname;
    string sex;
    Date   birthdate;
    string jobTitle;
    double basicSalary;
};

// ============================================================
//  CONSTANTS
// ============================================================

const string FILE_NAME       = "employee.txt";
const int    RETIRE_AGE      = 60;
const double TAX_RATE        = 0.10;
const double PENSION_RATE    = 0.07;
const double TRANSPORT_ALLOW = 500.0;

// ============================================================
//  UTILITY: STRING TO NUMBER CONVERSIONS (C++98 compatible)
// ============================================================

int stringToInt(const string& str) {
    istringstream iss(str);
    int result;
    iss >> result;
    return result;
}

double stringToDouble(const string& str) {
    istringstream iss(str);
    double result;
    iss >> result;
    return result;
}

// ============================================================
//  UTILITY: GET CURRENT DATE
// ============================================================

int currentYear() {
    time_t t = time(NULL);
    tm* now  = localtime(&t);
    return now->tm_year + 1900;
}
int currentMonth() {
    time_t t = time(NULL);
    tm* now  = localtime(&t);
    return now->tm_mon + 1;
}
int currentDay() {
    time_t t = time(NULL);
    tm* now  = localtime(&t);
    return now->tm_mday;
}

// ============================================================
//  UTILITY: AGE CALCULATOR
// ============================================================

int calcAge(const Date& bd) {
    int age = currentYear() - bd.year;
    if (currentMonth() < bd.month ||
       (currentMonth() == bd.month && currentDay() < bd.day))
        age--;
    return age;
}

// ============================================================
//  UTILITY: DATE VALIDATOR
// ============================================================

bool isValidDate(int d, int m, int y) {
    if (y < 1900 || y > currentYear()) return false;
    if (m < 1    || m > 12)            return false;
    int days[] = {31,28,31,30,31,30,31,31,30,31,30,31};
    if (y % 400 == 0 || (y % 4 == 0 && y % 100 != 0)) days[1] = 29;
    if (d < 1 || d > days[m-1])        return false;
    return true;
}

// ============================================================
//  UTILITY: NET SALARY
// ============================================================

double calcNetSalary(double basic) {
    return basic - (basic * TAX_RATE) - (basic * PENSION_RATE) + TRANSPORT_ALLOW;
}

// ============================================================
//  UTILITY: FULL NAME
// ============================================================

string fullName(const Employee& e) {
    return e.fname + " " + e.lname;
}

// ============================================================
//  UTILITY: TO-UPPER
// ============================================================

string toUpper(string s) {
    transform(s.begin(), s.end(), s.begin(), ::toupper);
    return s;
}

// ============================================================
//  SERIALIZE / DESERIALIZE
// ============================================================

string serialize(const Employee& e) {
    ostringstream oss;
    oss << e.id           << "|"
        << e.fname        << "|"
        << e.lname        << "|"
        << e.sex          << "|"
        << e.birthdate.day   << "|"
        << e.birthdate.month << "|"
        << e.birthdate.year  << "|"
        << e.jobTitle     << "|"
        << fixed << setprecision(2) << e.basicSalary;
    return oss.str();
}

Employee deserialize(const string& line) {
    Employee e;
    istringstream iss(line);
    string tok;
    
    getline(iss, tok, '|'); e.id               = stringToInt(tok);
    getline(iss, tok, '|'); e.fname            = tok;
    getline(iss, tok, '|'); e.lname            = tok;
    getline(iss, tok, '|'); e.sex              = tok;
    getline(iss, tok, '|'); e.birthdate.day    = stringToInt(tok);
    getline(iss, tok, '|'); e.birthdate.month  = stringToInt(tok);
    getline(iss, tok, '|'); e.birthdate.year   = stringToInt(tok);
    getline(iss, tok, '|'); e.jobTitle         = tok;
    getline(iss, tok, '|'); e.basicSalary      = stringToDouble(tok);
    return e;
}

// ============================================================
//  FILE I/O
// ============================================================

vector<Employee> loadAll() {
    vector<Employee> emp;
    ifstream fin(FILE_NAME.c_str());
    if (!fin) return emp;
    string line;
    while (getline(fin, line))
        if (!line.empty()) emp.push_back(deserialize(line));
    fin.close();
    return emp;
}

void saveAll(const vector<Employee>& emp) {
    ofstream fout(FILE_NAME.c_str());
    for (vector<Employee>::const_iterator it = emp.begin(); it != emp.end(); ++it)
        fout << serialize(*it) << "\n";
    fout.close();
}

// ============================================================
//  AUTO-INCREMENT ID
// ============================================================

int nextID(const vector<Employee>& emp) {
    int maxID = 1000;
    for (vector<Employee>::const_iterator it = emp.begin(); it != emp.end(); ++it)
        if (it->id > maxID) maxID = it->id;
    return maxID + 1;
}

// ============================================================
//  INPUT HELPERS
// ============================================================

void flushInput() {
    cin.ignore(numeric_limits<streamsize>::max(), '\n');
}

string readString(const string& prompt) {
    string s;
    while (true) {
        cout << prompt;
        getline(cin, s);
        if (!s.empty()) return s;
        cout << "  [!] Input cannot be empty. Try again.\n";
    }
}

int readInt(const string& prompt, int lo, int hi) {
    int v;
    while (true) {
        if (!prompt.empty()) cout << prompt;
        if (cin >> v && v >= lo && v <= hi) { flushInput(); return v; }
        cout << "  [!] Invalid. Enter a number (" << lo << "-" << hi << ").\n";
        cin.clear(); flushInput();
    }
}

int readIntAny(const string& prompt) {
    int v;
    while (true) {
        cout << prompt;
        if (cin >> v) { flushInput(); return v; }
        cout << "  [!] Invalid integer.\n";
        cin.clear(); flushInput();
    }
}

double readDouble(const string& prompt) {
    double v;
    while (true) {
        cout << prompt;
        if (cin >> v && v > 0) { flushInput(); return v; }
        cout << "  [!] Invalid. Enter a positive number.\n";
        cin.clear(); flushInput();
    }
}

string readSex(const string& prompt) {
    string s;
    while (true) {
        cout << prompt;
        getline(cin, s);
        if (toUpper(s) == "M" || toUpper(s) == "F") return toUpper(s);
        cout << "  [!] Enter M or F.\n";
    }
}

Date readDate(const string& prompt) {
    Date d;
    cout << prompt << "\n";
    while (true) {
        d.day   = readInt("    Day   (1-31)   : ", 1, 31);
        d.month = readInt("    Month (1-12)   : ", 1, 12);
        d.year  = readInt("    Year (1900-now): ", 1900, currentYear());
        if (isValidDate(d.day, d.month, d.year)) return d;
        cout << "  [!] Invalid date combination. Re-enter.\n";
    }
}

// ============================================================
//  DISPLAY HELPERS
// ============================================================

void printLine(int n, char c) { cout << string(n, c) << "\n"; }

void printTableHeader() {
    printLine(88, '=');
    cout << left
         << setw(6)  << "ID"
         << setw(16) << "First Name"
         << setw(16) << "Last Name"
         << setw(5)  << "Sex"
         << setw(5)  << "Age"
         << setw(22) << "Job Title"
         << setw(12) << "Basic(ETB)"
         << setw(12) << "Net(ETB)"
         << "\n";
    printLine(88, '-');
}

void printTableRow(const Employee& e) {
    cout << left
         << setw(6)  << e.id
         << setw(16) << e.fname
         << setw(16) << e.lname
         << setw(5)  << e.sex
         << setw(5)  << calcAge(e.birthdate)
         << setw(22) << e.jobTitle
         << setw(12) << fixed << setprecision(2) << e.basicSalary
         << setw(12) << calcNetSalary(e.basicSalary)
         << "\n";
}

void printDetailCard(const Employee& e) {
    double basic   = e.basicSalary;
    double tax     = basic * TAX_RATE;
    double pension = basic * PENSION_RATE;
    double net     = calcNetSalary(basic);

    cout << "\n"; printLine(54, '=');
    cout << "  EMPLOYEE DETAIL CARD\n";
    printLine(54, '-');
    cout << "  Employee ID    : " << e.id << "\n";
    cout << "  First Name     : " << e.fname << "\n";
    cout << "  Last Name      : " << e.lname << "\n";
    cout << "  Full Name      : " << fullName(e) << "\n";
    cout << "  Sex            : " << (e.sex == "M" ? "Male" : "Female") << "\n";
    cout << "  Birth Date     : "
         << setfill('0') << setw(2) << e.birthdate.day   << "/"
         << setw(2) << e.birthdate.month << "/"
         << setfill(' ') << e.birthdate.year << "\n";
    cout << "  Age            : " << calcAge(e.birthdate) << " years\n";
    cout << "  Job Title      : " << e.jobTitle << "\n";
    printLine(54, '-');
    cout << "  SALARY BREAKDOWN\n";
    printLine(54, '-');
    cout << right;
    cout << "  Basic Salary         : " << setw(10) << fixed << setprecision(2) << basic   << " ETB\n";
    cout << "  (-) Income Tax (10%) : " << setw(10) << tax     << " ETB\n";
    cout << "  (-) Pension    ( 7%) : " << setw(10) << pension << " ETB\n";
    cout << "  (+) Transport Allw   : " << setw(10) << TRANSPORT_ALLOW << " ETB\n";
    printLine(54, '-');
    cout << "  NET SALARY           : " << setw(10) << net     << " ETB\n";
    printLine(54, '=');
    cout << left << "\n";
}

// ============================================================
//  FIND BY ID
// ============================================================

int findByID(const vector<Employee>& emp, int id) {
    for (int i = 0; i < (int)emp.size(); i++)
        if (emp[i].id == id) return i;
    return -1;
}

// ============================================================
//  1. RECRUIT
// ============================================================

void recruitEmployee() {
    cout << "\n+------------------------------------+\n";
    cout <<   "|       RECRUIT NEW EMPLOYEE         |\n";
    cout <<   "+------------------------------------+\n";

    vector<Employee> emp = loadAll();
    Employee e;
    e.id = nextID(emp);
    cout << "  Auto-assigned ID : " << e.id << "\n\n";

    e.fname       = readString("  First Name      : ");
    e.lname       = readString("  Last Name       : ");
    e.sex         = readSex   ("  Sex (M/F)       : ");
    e.birthdate   = readDate  ("  Birth Date");
    e.jobTitle    = readString("  Job Title       : ");
    e.basicSalary = readDouble("  Basic Salary    : ");

    int age = calcAge(e.birthdate);
    if (age >= RETIRE_AGE) {
        cout << "\n  [REJECTED] This person is " << age
             << " years old, which exceeds the retirement age of "
             << RETIRE_AGE << ". Cannot recruit.\n";
        return;
    }

    emp.push_back(e);
    saveAll(emp);
    cout << "\n  [SUCCESS] " << fullName(e)
         << " recruited successfully! ID: " << e.id << "\n";
}

// ============================================================
//  2. RETIRE
// ============================================================

void checkRetirements(bool silent) {
    vector<Employee> emp = loadAll();
    vector<Employee> remaining;
    bool anyFound = false;

    for (vector<Employee>::const_iterator it = emp.begin(); it != emp.end(); ++it) {
        if (calcAge(it->birthdate) >= RETIRE_AGE) {
            if (!anyFound) {
                cout << "\n+--------------------------------------------------+\n";
                cout <<   "|            RETIREMENT NOTIFICATION               |\n";
                cout <<   "+--------------------------------------------------+\n";
                anyFound = true;
            }
            printDetailCard(*it);
            cout << "  Employee has reached retirement age (" << RETIRE_AGE << ").\n";
            cout << "  Confirm retirement and remove from records? (y/n): ";
            char ch; cin >> ch; flushInput();
            if (ch == 'y' || ch == 'Y') {
                cout << "  [OK] " << fullName(*it) << " has been retired.\n\n";
            } else {
                cout << "  [--] Skipped for now.\n\n";
                remaining.push_back(*it);
            }
        } else {
            remaining.push_back(*it);
        }
    }

    if (!anyFound && !silent)
        cout << "\n  [i] No employees have reached retirement age (" << RETIRE_AGE << ").\n";

    if (anyFound) saveAll(remaining);
}

// ============================================================
//  3. FIRE
// ============================================================

void fireEmployee() {
    cout << "\n+------------------------------------+\n";
    cout <<   "|          FIRE EMPLOYEE             |\n";
    cout <<   "+------------------------------------+\n";

    vector<Employee> emp = loadAll();
    if (emp.empty()) { cout << "  [i] No employees on record.\n"; return; }

    int id  = readIntAny("  Enter Employee ID to fire: ");
    int idx = findByID(emp, id);
    if (idx == -1) { cout << "  [!] Employee ID " << id << " not found.\n"; return; }

    printDetailCard(emp[idx]);
    cout << "  Confirm: Fire " << fullName(emp[idx]) << "? (y/n): ";
    char ch; cin >> ch; flushInput();

    if (ch == 'y' || ch == 'Y') {
        string name = fullName(emp[idx]);
        emp.erase(emp.begin() + idx);
        saveAll(emp);
        cout << "  [OK] " << name << " fired and removed from all records.\n";
    } else {
        cout << "  [--] Cancelled.\n";
    }
}

// ============================================================
//  4. CALCULATE NET SALARY
// ============================================================

void calcSalaryMenu() {
    cout << "\n+------------------------------------+\n";
    cout <<   "|       CALCULATE NET SALARY         |\n";
    cout <<   "+------------------------------------+\n";
    cout << "  1. All Employees\n"
         << "  2. Single Employee\n"
         << "  Choice: ";
    int ch = readInt("", 1, 2);

    vector<Employee> emp = loadAll();
    if (emp.empty()) { cout << "  [i] No employees on record.\n"; return; }

    if (ch == 1) {
        printTableHeader();
        double totalBasic = 0, totalNet = 0;
        for (vector<Employee>::const_iterator it = emp.begin(); it != emp.end(); ++it) {
            printTableRow(*it);
            totalBasic += it->basicSalary;
            totalNet   += calcNetSalary(it->basicSalary);
        }
        printLine(88, '-');
        cout << right
             << setw(72) << "TOTAL BASIC PAYROLL : "
             << fixed << setprecision(2) << totalBasic << " ETB\n"
             << setw(72) << "TOTAL NET   PAYROLL : "
             << totalNet << " ETB\n";
        printLine(88, '=');
        cout << left << "  Total Employees: " << emp.size() << "\n";
    } else {
        int id = readIntAny("  Enter Employee ID: ");
        int idx = findByID(emp, id);
        if (idx == -1) cout << "  [!] Employee not found.\n";
        else           printDetailCard(emp[idx]);
    }
}

// ============================================================
//  5. DISPLAY
// ============================================================

void displayMenu() {
    cout << "\n+------------------------------------+\n";
    cout <<   "|         DISPLAY EMPLOYEES          |\n";
    cout <<   "+------------------------------------+\n";
    cout << "  1. All Employees\n"
         << "  2. Single Employee\n"
         << "  Choice: ";
    int ch = readInt("", 1, 2);

    vector<Employee> emp = loadAll();
    if (emp.empty()) { cout << "  [i] No employees on record.\n"; return; }

    if (ch == 1) {
        printTableHeader();
        for (vector<Employee>::const_iterator it = emp.begin(); it != emp.end(); ++it)
            printTableRow(*it);
        printLine(88, '=');
        cout << "  Total Employees: " << emp.size() << "\n";
    } else {
        int id = readIntAny("  Enter Employee ID: ");
        int idx = findByID(emp, id);
        if (idx == -1) cout << "  [!] Employee not found.\n";
        else           printDetailCard(emp[idx]);
    }
}

// ============================================================
//  6. UPDATE EMPLOYEE
// ============================================================

void updateEmployee() {
    cout << "\n+------------------------------------+\n";
    cout <<   "|         UPDATE EMPLOYEE            |\n";
    cout <<   "+------------------------------------+\n";

    vector<Employee> emp = loadAll();
    if (emp.empty()) { cout << "  [i] No employees on record.\n"; return; }

    int id  = readIntAny("  Enter Employee ID to update: ");
    int idx = findByID(emp, id);
    if (idx == -1) { cout << "  [!] Employee ID " << id << " not found.\n"; return; }

    printDetailCard(emp[idx]);

    cout << "  Choose field to update:\n"
         << "  1. First Name\n  2. Last Name\n  3. Sex\n"
         << "  4. Birth Date\n  5. Job Title\n  6. Basic Salary\n"
         << "  0. Cancel\n"
         << "  Choice: ";
    int ch = readInt("", 0, 6);

    Employee& e = emp[idx];
    switch (ch) {
        case 1: e.fname        = readString("  New First Name  : "); break;
        case 2: e.lname        = readString("  New Last Name   : "); break;
        case 3: e.sex          = readSex   ("  New Sex (M/F)   : "); break;
        case 4: {
            e.birthdate = readDate("  New Birth Date");
            int newAge = calcAge(e.birthdate);
            if (newAge >= RETIRE_AGE)
                cout << "  [!] Warning: age " << newAge
                     << " >= retirement age. Will flag on next scan.\n";
            break;
        }
        case 5: e.jobTitle     = readString("  New Job Title   : "); break;
        case 6: e.basicSalary  = readDouble("  New Salary (ETB): "); break;
        case 0: cout << "  [--] Cancelled.\n"; return;
    }
    saveAll(emp);
    cout << "  [OK] Record updated successfully.\n";
    printDetailCard(emp[idx]);
}

// ============================================================
//  7. SEARCH EMPLOYEE
// ============================================================

void searchEmployee() {
    cout << "\n+------------------------------------+\n";
    cout <<   "|         SEARCH EMPLOYEE            |\n";
    cout <<   "+------------------------------------+\n";
    cout << "  1. Search by ID\n"
         << "  2. Search by First or Last Name\n"
         << "  Choice: ";
    int ch = readInt("", 1, 2);

    vector<Employee> emp = loadAll();
    if (emp.empty()) { cout << "  [i] No employees on record.\n"; return; }

    if (ch == 1) {
        int id  = readIntAny("  Enter ID: ");
        int idx = findByID(emp, id);
        if (idx == -1) cout << "  [!] Not found.\n";
        else           printDetailCard(emp[idx]);
    } else {
        string kw = readString("  Enter name keyword: ");
        string kwU = toUpper(kw);
        bool found = false;
        printTableHeader();
        for (vector<Employee>::const_iterator it = emp.begin(); it != emp.end(); ++it) {
            if (toUpper(it->fname).find(kwU) != string::npos ||
                toUpper(it->lname).find(kwU) != string::npos) {
                printTableRow(*it);
                found = true;
            }
        }
        if (found) printLine(88, '=');
        else cout << "  [!] No employee matched \"" << kw << "\".\n";
    }
}

// ============================================================
//  MAIN MENU
// ============================================================

void showMenu() {
    cout << "\n";
    cout << "  +==========================================+\n";
    cout << "  |     EMPLOYEE MANAGEMENT SYSTEM  v2.0    |\n";
    cout << "  +==========================================+\n";
    cout << "  |  1. Recruit   an Employee                |\n";
    cout << "  |  2. Retire    (Check & Process All)      |\n";
    cout << "  |  3. Fire      an Employee                |\n";
    cout << "  |  4. Calculate Net Salary                 |\n";
    cout << "  |  5. Display   Employees                  |\n";
    cout << "  |  6. Update    an Employee                |\n";
    cout << "  |  7. Search    an Employee                |\n";
    cout << "  |  0. Exit                                 |\n";
    cout << "  +==========================================+\n";
    cout << "  Select option: ";
}

// ============================================================
//  ENTRY POINT
// ============================================================

int main() {
    cout << "\n";
    cout << "  ============================================\n";
    cout << "    EMPLOYEE MANAGEMENT SYSTEM  - STARTUP\n";
    cout << "  ============================================\n";
    cout << "  [AUTO-CHECK] Scanning for retirement-eligible employees...\n";
    checkRetirements(true);

    int choice;
    do {
        showMenu();
        if (!(cin >> choice)) {
            cin.clear(); flushInput();
            choice = -1;
        } else {
            flushInput();
        }
        switch (choice) {
            case 1: recruitEmployee();  break;
            case 2: checkRetirements(false); break;
            case 3: fireEmployee();     break;
            case 4: calcSalaryMenu();   break;
            case 5: displayMenu();      break;
            case 6: updateEmployee();   break;
            case 7: searchEmployee();   break;
            case 0: cout << "\n  Goodbye!\n\n"; break;
            default: cout << "\n  [!] Invalid option. Choose 0-7.\n";
        }
    } while (choice != 0);

    return 0;
}